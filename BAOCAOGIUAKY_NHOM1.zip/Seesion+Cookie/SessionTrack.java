package session_example;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class SessionTrack
 */
@WebServlet("/SessionTrack")
public class SessionTrack extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SessionTrack() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		// Tạo một đối tượng session nếu nó chưa được tạo.
        HttpSession session = request.getSession(true);
        // Lấy thời gian tạo session.
        Date createTime = new Date(session.getCreationTime());
        // Nhận thời gian truy cập cuối cùng của trang web này.
        Date lastAccessTime = new Date(session.getLastAccessedTime());
        String title = "Welcome Back to my website";
		Integer visitCount = new Integer(0);
        String visitCountKey = new String("visitCount");
        String userIDKey = new String("userID");
        String userID = new String("123456789");
        // Kiểm tra xem đây có phải là người mới đến trên trang web hay không.
        if (session.isNew()) {
            title = "Welcome to my website";
            session.setAttribute(userIDKey, userID);
        } else {
            visitCount = (Integer) session.getAttribute(visitCountKey);
            visitCount = visitCount + 1;
            userID = (String) session.getAttribute(userIDKey);
        }
        session.setAttribute(visitCountKey, visitCount);
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<body>");
        out.println("<head><title> Hello Session </title></head>");
        out.println("<h1 align = \"center\"> "+" Hello Session "+"</h1> ");
        out.println("<h2 align = \"center\"> "+" Session Information "+"</h2> ");
        out.println("<table border = \"1\" align = \"center\">");
        out.println("<tr>");
        out.println("<th>Session info</th>");
        out.println("<th>Value</th>");
        out.println("</tr>");
        
        out.println("<tr>");
        out.println("<td>id</td>");
        out.println("<td>" + session.getId() + "</td>");
        out.println("</tr>");
        
        out.println("<tr>");
        out.println("<td>Creation Time</td>");
        out.println("<td>" + createTime + "  </td>");
        out.println("</tr>");
        
        out.println("<tr>");
        out.println("<td>Time of Last Access</td>");
        out.println("<td>" + lastAccessTime + "  </td>");
        out.println("</tr>");
        
        out.println("<tr>");
        out.println("<td>User ID</td>");
        out.println("<td>" + userID + "  </td>");
        out.println("</tr>");
        
        out.println("<tr>");
        out.println("<td>Number of visits</td>");
        out.println("<td>" + visitCount + "</td>");
        out.println("</tr>");
        out.println("</table>");
        out.println("</body>");
        out.println("</html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
